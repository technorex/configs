﻿using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace ZOiSTest
{
    public class ConfigModel
    {
        public List<int> Years { get; set; }
        public int AnalyticLevel { get; set; }
        public bool TakeBuffers { get; set; }


        private static ConfigModel _confg;
        public static ConfigModel Get()
        {
            return _confg ?? (_confg = new ConfigModel());
        }


        private ConfigModel()
        {
            this.Years = new List<int>();
            Init();
        }

        private void Init()
        {
            this.AnalyticLevel = int.Parse(ConfigurationManager.AppSettings["PoziomAnalityki"]);
            this.TakeBuffers = bool.Parse(ConfigurationManager.AppSettings["UwzglednijBufory"]);
            this.Years = ConfigurationManager.AppSettings["Lata"].Split(',').Select(x => int.Parse(x)).ToList();
        }

    }
}