﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficeOpenXml;

namespace ZOiSTest
{
    class Program
    {
        static void Main(string[] args)
        {
            ConfigModel configModel = ConfigModel.Get();

            using (FileStream fs = new FileStream(@"D:\Poligon\files\funny.xlsx", FileMode.Create, FileAccess.Write,
                FileShare.ReadWrite))
            {
                ExcelPackage excel = new ExcelPackage(fs);
                ExcelWorksheet ws = excel.Workbook.Worksheets.Add("Test");

                ws.Cells[1, 1].Value = "Test";


                excel.Save();
                fs.Flush();
            }


            Console.ReadKey();
        }
    }
}
